﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace szachy
{
    public partial class uC : UserControl
    {
        public int pozX;
        public int pozY;
        public uC()
        {
            InitializeComponent();
        }

        private void uC_Load(object sender, EventArgs e)
        {

        }

    }
}
